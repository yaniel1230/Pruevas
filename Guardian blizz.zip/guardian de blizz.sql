-- Guardián de la Ventisca para AzerothCore 3.3.5
SET @ENTRY := 5764;
SET @SOURCETYPE := 0;

-- 1. Eliminar scripts existentes
DELETE FROM `smart_scripts` WHERE `entryorguid` = @ENTRY AND `source_type` = @SOURCETYPE;

-- 2. Habilitar SmartAI
UPDATE `creature_template` SET `AIName` = 'SmartAI' WHERE `entry` = @ENTRY LIMIT 1;

-- 3. Insertar nuevos Smart Scripts
INSERT INTO `smart_scripts` 
(`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, `action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
-- Lanza Dedo de la Muerte cada 1-2 segundos en combate
(@ENTRY, @SOURCETYPE, 0, 0, 0, 0, 100, 0, 1000, 2000, 3000, 4000, 11, 5, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 'Guardián de la Ventisca - Lanza Dedo de la Muerte (ID:5)'),
-- Grito al entrar en combate (solo primera vez)
(@ENTRY, @SOURCETYPE, 1, 0, 4, 0, 100, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'Guardián de la Ventisca - Grito de combate'),
-- Mensaje al matar a un jugador
(@ENTRY, @SOURCETYPE, 2, 0, 6, 0, 100, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 'Guardián de la Ventisca - Mensaje al matar');

-- 4. Configurar textos de la criatura
DELETE FROM `creature_text` WHERE `entry` = @ENTRY;
INSERT INTO `creature_text` 
(`entry`, `groupid`, `id`, `text`, `type`, `language`, `probability`, `emote`, `duration`, `sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
(@ENTRY, 0, 0, '¡ESTA ÁREA ESTÁ FUERA DE LÍMITES!', 14, 0, 100, 0, 0, 0, 0, 0, 'Guardián de la Ventisca - Grito de combate'),
(@ENTRY, 1, 0, 'El Guardián de la Ventisca te ha matado', 16, 0, 100, 0, 0, 0, 0, 0, 'Guardián de la Ventisca - Mensaje de muerte');

-- 5. Actualizar plantilla de la criatura (compatible con AC 3.3.5)
UPDATE `creature_template` SET 
    `minlevel` = 255,
    `maxlevel` = 255,
    `exp` = 2, -- Wrath of the Lich King
    `faction` = 14, -- Monstruosidad
    `speed_walk` = 3,
    `speed_run` = 3,
    `BaseAttackTime` = 2000,
    `RangeAttackTime` = 2000,
    `unit_class` = 2, -- Guerrero
    `unit_flags` = 256, -- Flag especial
    `unit_flags2` = 2048,
    `type` = 10, -- No especificado
    `type_flags` = 4,
    `HealthModifier` = 1000.0,
    `ManaModifier` = 1.0,
    `ArmorModifier` = 100.0,
    `DamageModifier` = 100.0,
    `flags_extra` = 2 -- No parry
WHERE `entry` = @ENTRY;

-- 6. Actualizar stats de nivel (requiere AzerothCore)
DELETE FROM `creature_template_scaling` WHERE `Entry` = @ENTRY;
INSERT INTO `creature_template_scaling` 
(`Entry`, `LevelScalingMin`, `LevelScalingMax`, `LevelScalingDeltaMin`, `LevelScalingDeltaMax`) VALUES 
(@ENTRY, 255, 255, 0, 0);