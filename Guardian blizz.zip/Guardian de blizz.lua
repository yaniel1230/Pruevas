local SPELL_FINGER_OF_DEATH = 31984
local YELL_TEXT = "¡ESTA ÁREA ESTÁ FUERA DE LOS LÍMITES!"
local KILL_MESSAGE = "El Guardián de Ventisca te ha matado"

local function OnEnterCombat(event, creature, target)
    creature:SendUnitYell(YELL_TEXT, 0)
    creature:RegisterEvent(function() DedoDeLaMuerte(event, 1000, nil, creature) end, 1000, 1)
end

local function OnLeaveCombat(event, creature)
    creature:RemoveEvents()
end

local function DedoDeLaMuerte(event, delay, repeats, creature)
    local victim = creature:GetVictim()
    if victim and victim:IsAlive() then
        creature:CastSpell(victim, SPELL_FINGER_OF_DEATH, true)
        creature:RegisterEvent(DedoDeLaMuerte, 5000, 0) -- Ahora se repite cada 5 segundos
    end
end

local function OnKilledUnit(event, creature, victim)
    if victim:GetTypeId() == TypeID_Player then
        victim:SendBroadcastMessage(KILL_MESSAGE)
    end
end

RegisterCreatureEvent(5764, 1, OnEnterCombat)  -- EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(5764, 2, OnLeaveCombat)  -- EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(5764, 4, OnKilledUnit)   -- EVENT_ON_KILLED_UNIT (corregido de 3 a 4)